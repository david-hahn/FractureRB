patch for hyena core master dated 2013-Nov-04
replace originals with files from this archive
enables MSVC build and fracture simulation with HyENA